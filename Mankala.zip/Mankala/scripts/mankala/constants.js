export default {
  PLAYER_ONE: true,
  PLAYER_TWO: false,
};
