import c from "../constants.js";

export default class HumanPlayer {
  constructor(whichPlayer) {
    this.whichPlayer = whichPlayer;
  }

  makeMove(move) {}
}
