README

Pliki zapisane są w następującym formacie:
* w pierwszej linii znajdują się wymiaru X;Y dla płytki drukowanej [liczby całkowite]
* w następnych linijkach znajdują się pary punktów, które mają tworzyć połączenie w formacie X1;Y1;X2;Y2 
[liczby całkowite] {X1;Y1 - współrzędne punktu początkowego, X2;Y2 - współrzędne punktu końcowego}
